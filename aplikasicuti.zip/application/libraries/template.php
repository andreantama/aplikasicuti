<?php
class template extends CI_Controller{
	protected $_ci;
	function __construct(){
	$this->_ci =&get_instance();

	}
	  public function display($template,$data=null)
    {
    
        
        $data['_content']=$this->_ci->load->view(
            $template,$data, true);
        $this->_ci->load->view('/template/template.php',$data);

    }

}
?>