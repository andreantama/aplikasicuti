<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct() {
          parent::__construct();
          $this->load->model("Mlogin", "model");
     }
	public function index()
	{

		if($this->input->post("simpan")){
			$this->form_validation->set_rules("username", "Username", "required");
			$this->form_validation->set_rules("password", "Password", "required");
			$this->form_validation->set_rules("status", "Status", "required");
			if($this->form_validation->run() == TRUE){
				if($this->model->ceklogin() == TRUE){
					redirect("beranda");
				}
				else{
					$this->session->set_flashdata('notifikasierror', TRUE);
				}
			}
		}
		$this->load->view('login');
	}
	public function logout(){
		$this->model->logout();
		redirect("login");
	}
}
