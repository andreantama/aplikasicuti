<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Beranda extends MY_Controller{
	public function __construct() {
          parent::__construct();
          $this->load->model("mberanda","model");

     }
     public function index(){
     	$data['cekstatus'] = $this->cekstatus();
     	//$this->load->view("beranda",$data);
        $this->template->display("beranda" ,$data);
     }
     public function pengguna(){
        if($this->cekstatus() != "superadmin"): redirect("/beranda"); endif;
        $data['cekstatus'] = $this->cekstatus();
     	$data['tampil'] = $this->db->where("status_hapus", 0)->order_by("id_pengguna","DESC")->get("jc_pengguna")->result();
     	//$this->load->view("pengguna", $data);
        $this->template->display("pengguna" ,$data);
     }
     public function tambahpengguna(){
        if($this->cekstatus() != "superadmin"): redirect("/beranda"); endif;
     	if($this->input->post("simpan")){
     		$this->form_validation->set_rules("nip", "Nip", "required");
     		$this->form_validation->set_rules("nama", "Nama", "required");
     		$this->form_validation->set_rules("alamat", "Alamat", "required");
     		$this->form_validation->set_rules("telp", "Telp", "required|max_length[12]");
     		$this->form_validation->set_rules("username", "Username", "required|is_unique[jc_pengguna.username_pengguna]");
     		$this->form_validation->set_rules("password1", "Password", "required");
     		$this->form_validation->set_rules("password2", "Ulangi Password", "required|matches[password1]");
     		$this->form_validation->set_rules("status", "Status", "required");

     		if($this->form_validation->run() == TRUE){
 				$data = array(
 					"nip_pengguna" => $this->input->post("nip"),
 					"nama_pengguna" => $this->input->post("nama"),
 					"alamat_pengguna" => $this->input->post("alamat"),
 					"telp_pengguna" => $this->input->post("telp"),
 					"username_pengguna" => $this->input->post("username"),
 					"password_pengguna" => $this->input->post("password1"),
 					"status_pengguna" => $this->input->post("status"),
 					"status_hapus" => 0
 					);
 				$this->db->insert("jc_pengguna", $data);
     		}
     	}
        $data['cekstatus'] = $this->cekstatus();
     	//$this->load->view("tambahpengguna");
        $this->template->display("tambahpengguna" ,$data);
     }
     public function editpengguna($id){
        if($this->cekstatus() != "superadmin"): redirect("/beranda"); endif;
     	if($this->input->post("simpan")){
     		$this->form_validation->set_rules("nip", "Nip", "required");
     		$this->form_validation->set_rules("nama", "Nama", "required");
     		$this->form_validation->set_rules("alamat", "Alamat", "required");
     		$this->form_validation->set_rules("telp", "Telp", "required|max_length[12]");
     		$this->form_validation->set_rules("status", "Status", "required");

     		if($this->form_validation->run() == TRUE){
 				$data = array(
 					"nip_pengguna" => $this->input->post("nip"),
 					"nama_pengguna" => $this->input->post("nama"),
 					"alamat_pengguna" => $this->input->post("alamat"),
 					"telp_pengguna" => $this->input->post("telp"),
 					"status_pengguna" => $this->input->post("status")
 					);
 				$where = array("id_pengguna" => $id);
 				$this->db->update("jc_pengguna", $data, $where);
     		}
     	}
     	$data['tampil'] = $this->db->where("id_pengguna",$id)->get("jc_pengguna")->row();
        $data['cekstatus'] = $this->cekstatus();
        $this->template->display("editpengguna" ,$data);
     }
     public function hapuspengguna($id){
        if($this->cekstatus() != "superadmin"): redirect("/beranda"); endif;
     	$data = array(
 					"status_hapus" => 1
 					);
 				$where = array("id_pengguna" => $id);
 				$this->db->update("jc_pengguna", $data, $where);
 		redirect("beranda/pengguna");
     }










//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//









     public function jadwalcuti(){
        if($this->cekstatus() != "admin"): redirect("/beranda"); endif;
     	$data['tampil'] = $this->db->where("status_jadwal", 0)->get("jc_jadwal")->result();
                        $data['cekstatus'] = $this->cekstatus();
     	//$this->load->view("jadwalcuti",$data);
        $this->template->display("jadwalcuti" ,$data);
     }
     public function tambahjadwalcuti(){
        if($this->cekstatus() != "admin"): redirect("/beranda"); endif;
     	$tahun =  date('Y');
     	if($this->input->post("simpan")){
     		$this->form_validation->set_rules("tahun", "Tahun", "required|callback_cektahun|callback_cektahunn");
     		$this->form_validation->set_rules("cutibersama", "Jadwal Cuti Bersama", "required|callback_cekcutibersama");

     		if($this->form_validation->run() == TRUE){
     			$sisa = 12 - $this->input->post("cutibersama");
     			$data = array(
     				"tahun_jadwal" => $this->input->post("tahun"),
     				"cutibersama_jadwal" => $this->input->post("cutibersama"),
     				"sisacuti_jadwal" => $sisa,
     				"status_jadwal" => 0
     				);
     			$this->db->insert("jc_jadwal", $data);
     		}
     	}
                        $data['cekstatus'] = $this->cekstatus();
     	//$this->load->view("tambahjadwalcuti");
         $this->template->display("tambahjadwalcuti" ,$data);
     }
     public function editjadwalcuti($id){
        if($this->cekstatus() != "admin"): redirect("/beranda"); endif;
     	if($this->input->post("simpan")){
     		$this->form_validation->set_rules("tahun", "Tahun", "required");
     		$this->form_validation->set_rules("cutibersama", "Jadwal Cuti Bersama", "required|callback_cekcutibersama");
     		if($this->form_validation->run() == TRUE){
     			$sisa = 12 - $this->input->post("cutibersama");
     			$data = array(
     				"cutibersama_jadwal" => $this->input->post("cutibersama"),
     				"sisacuti_jadwal" => $sisa,
     				"status_jadwal" => 0
     				);
     			$this->db->update("jc_jadwal", $data, array("id_jadwal"=> $id));
     			//echo $this->db->last_query();
     		}
     	}
     	$data['tampil'] = $this->db->where("id_jadwal",$id)->get("jc_jadwal")->row();
                        $data['cekstatus'] = $this->cekstatus();
     	//$this->load->view("editjadwalcuti",$data);
        $this->template->display("editjadwalcuti" ,$data);
     }
     public function hapusjadwalcuti($id){
        if($this->cekstatus() != "admin"): redirect("/beranda"); endif;
     		$data = array(
 					"status_jadwal" => 1
 					);
 				$where = array("id_jadwal" => $id);
 				$this->db->update("jc_jadwal", $data, $where);
 		redirect("beranda/jadwalcuti/");
     }

    public function cektahun($str){
       	$tahun =  date('Y');
       	 if ($str < $tahun)
             {
                        $this->form_validation->set_message('cektahun', 'Tahun tidak boleh kurang dari tahun '.$tahun);
                        return FALSE;
             }
             else
             {
                        return TRUE;
             }
       }
    public function cektahunn($str){
    	$cek = $this->db->where("tahun_jadwal" ,$str)->where("status_jadwal", 0)->get("jc_jadwal");
    	if($cek->num_rows()  == 1) {
                        $this->form_validation->set_message('cektahunn', "Tahun '".$str."' sudah tersedia");
                        //$this->form_validation->set_message('cektahunn', $this->db->last_query());
                        return FALSE;
             }
             else
             {
                        return TRUE;
             }
    }
    public function cekcutibersama($str){
    	if($str > 12){
    		   $this->form_validation->set_message('cekcutibersama', 'Tidak boleh lebih lebih dari 12');
                return FALSE;
    	}
    	 else
             {
                        return TRUE;
             }

    }





//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//










    public function cutianggota(){
        if($this->cekstatus() != "admin"): redirect("/beranda"); endif;
    	$data['tampil'] = $this->db->where("status_pengguna", "user")->order_by("nama_pengguna", "ASC")->get("jc_pengguna")->result();
    	                $data['cekstatus'] = $this->cekstatus();
        //$this->load->view("cutianggota", $data);
                $this->template->display("cutianggota" ,$data);
    }
    public function tambahcuti($id){
        if($this->cekstatus() != "admin"): redirect("/beranda"); endif;

    	if($this->input->post("simpan")){
    		$this->form_validation->set_rules("tahun", "Tahun", "required");
    		$this->form_validation->set_rules("tanggal", "Tanggal", "required");
    		if($this->form_validation->run() == TRUE){
    			$data = array(
    				"id_pengguna" => $id,
    				"id_jadwal" => $this->input->post("tahun"),
    				"tanggal_jadwalpengguna" => $this->input->post("tanggal")
    				);
    			$this->db->insert("jc_jadwalpengguna", $data);
       		}
    	}
    	$data['idanggota'] = $id;
    	$data['tampiltahun'] = $this->db->where("status_jadwal", 0)->order_by("tahun_jadwal", "ASC")->get("jc_jadwal")->result();
    	                $data['cekstatus'] = $this->cekstatus();
        //$this->load->view("tambahcutianggota", $data);
        $this->template->display("tambahcutianggota" ,$data);
    }
    public function cutidiambil($id){
        if($this->cekstatus() != "admin"): redirect("/beranda"); endif;
    	$data['idanggota'] = $id;
    	$data['tampilanggota'] = $this->db->where("id_pengguna", $id)->get("jc_pengguna")->row();
    	$data['tampiljadwal'] = $this->db->where("id_pengguna", $id)->order_by("id_jadwalpengguna")->get("jc_jadwalpengguna")->result();
    	$data['cekstatus'] = $this->cekstatus();
        //$this->load->view("detailcutidiambil", $data);
        $this->template->display("detailcutidiambil" ,$data);
    }
    public function editdetailcutidiambil($idd){
    	if($this->cekstatus() != "admin"): redirect("/beranda"); endif;
    	if($this->input->post("simpan")){
    		$this->form_validation->set_rules("tahun", "Tahun", "required");
    		$this->form_validation->set_rules("tanggal", "Tanggal", "required");
    		if($this->form_validation->run() == TRUE){
    			$data = array(
    				"id_jadwal" => $this->input->post("tahun"),
    				"tanggal_jadwalpengguna" => $this->input->post("tanggal")
    				);
    			$this->db->update("jc_jadwalpengguna", $data, array("id_jadwalpengguna" => $idd));
    			echo $this->db->last_query();
       		}
    	}
    	$tampiljadwalpengguna = $this->db->where("id_jadwalpengguna", $idd)->get("jc_jadwalpengguna")->row();
    	$id = $tampiljadwalpengguna->id_pengguna;
    	$data['tampiljadwalcuti'] = $tampiljadwalpengguna ;
    	$data['idanggota'] = $tampiljadwalpengguna->id_pengguna;
    	$data['tampiltahun'] = $this->db->where("status_jadwal", 0)->order_by("tahun_jadwal", "ASC")->get("jc_jadwal")->result();
    	                $data['cekstatus'] = $this->cekstatus();
                         $this->template->display("editdetailcutidiambil" ,$data);
       //$this->load->view("editdetailcutidiambil", $data);
    }
    public function hapusdetailcutidiambil($id,$idanggota){
        if($this->cekstatus() != "admin"): redirect("/beranda"); endif;
    	$this->db->delete('jc_jadwalpengguna', array("id_jadwalpengguna" => $id));  // Produces: // DELETE FROM mytable  // WHERE id = $id
    	redirect("beranda/cutidiambil/$idanggota");
    }



    public function detailtanggalcutiuser(){
        if($this->cekstatus() != "user"): redirect("/beranda"); endif;
        $username = $this->session->userdata("username");
        $tampilanggota = $this->db->where("username_pengguna", $username)->get("jc_pengguna")->row();
        $data['tampiljadwal'] = $this->db->where("id_pengguna", $tampilanggota->id_pengguna)->order_by("id_jadwalpengguna")->get("jc_jadwalpengguna")->result();
        $data['cekstatus'] = $this->cekstatus();
        $this->template->display("detailtanggalcutiuser" ,$data);

    }




}
