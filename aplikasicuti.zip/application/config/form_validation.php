<?php
$config['error_prefix'] = '<div class="errorku">';
$config['error_suffix'] = '</div>';
?>