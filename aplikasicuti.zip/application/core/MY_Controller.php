<?php
	class MY_Controller extends CI_Controller{
		public function __construct(){
			parent:: __construct();
			$this->load->library("template","template");
			if($this->session->userdata("username") == FALSE){
				redirect("/login");
			}
		}
		public function cekstatus(){
			$username = $this->session->userdata("username");
			$data = $this->db->where("username_pengguna", $username)->get("jc_pengguna")->row();
			return $data->status_pengguna;
		}

	}
?>