<?php
class Mlogin extends CI_Model {
	public function ceklogin(){
		$username = $this->input->post("username");
		$password = $this->input->post("password");
		$status = $this->input->post("status");
		$cek_user = $this->db->where("username_pengguna",$username)
							 ->get("jc_pengguna");
		$pass = $this->db->where("username_pengguna",$username)
							 ->get("jc_pengguna")
							 ->row();
		if($cek_user->num_rows() > '0'){
			if($pass->status_hapus == 0){
						if($status == $pass->status_pengguna){
							if($password == $pass->password_pengguna){
								$data = array("username" => $username);
								$this->session->set_userdata($data);
								return TRUE;
							}
							else{
								return FALSE;
							}
						}
						else{
							return FALSE;
						}
						
					}
					else{
				return FALSE;
			}
			}

		
		else{
			return FALSE;
		}

	}
	public function logout(){
		$this->session->unset_userdata(array("username"=> ""));
		$this->session->sess_destroy();
	}
}
?>