<?php
class Mberanda extends CI_Model {
	public function tampilanggota($id){
		return $this->db->get("jc_pengguna")->row();
	}
	public function tampiltahun($id){
		return $this->db->get("jc_jadwal")->row();
	}
	public function sisacuti($idanggota, $idjadwal, $sisacutijadwal){
		$jumlahtelahdiambil = $this->db->where("id_pengguna", $idanggota)
										->where("id_jadwal", $idjadwal)
										->get("jc_jadwalpengguna")
										->num_rows();
		return $sisabelumdiambil = $sisacutijadwal - $jumlahtelahdiambil;
	}
}