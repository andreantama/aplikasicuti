 <div class="row">
    <div class="col-lg-12">
       <section class="panel">
          <header class="panel-heading">
              Data Cuti
          </header>
        <div class="panel-body">
		<label class="col-sm-2 col-sm-2 control-label">Nip : <?php echo $tampilanggota->nip_pengguna;?></label>
		<label class="col-sm-2 col-sm-2 control-label">Nama : <?php echo $tampilanggota->nama_pengguna;?></label>
		   <a href="<?php echo base_url();?>beranda/cutianggota/" class='btn btn-default' >Kembali</a>
</div>
</section>
</div></div>

 <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">Tanggal Cuti yang diambil</header>
            <div class="panel-body">
                  <div class="adv-table">
<table  class="display table table-bordered table-striped" id="example">
<thead>
<tr>
	<th>No</th>
	<th>Tahun</th>
	<th>Tanggal</th>
	<th>Edit</th>
	<th>Hapus</th>
</tr>
</thead><tbody>
<?php $i = 1; foreach ($tampiljadwal as $row) :?>
<tr>
	<td><?php echo $i++;?></td>
	<td><?php echo $this->model->tampiltahun($row->id_jadwal)->tahun_jadwal;?></td>
	<td><?php echo $row->tanggal_jadwalpengguna;?></td>
	<td><a href="<?php echo base_url();?>beranda/editdetailcutidiambil/<?php echo $row->id_jadwalpengguna;?>">Edit</a></td>
	<td><a href="<?php echo base_url();?>beranda/hapusdetailcutidiambil/<?php echo $row->id_jadwalpengguna.'/'.$idanggota;?>">Hapus</a></td>
</tr>
<?php endforeach;?>
</tbody>
</table>