 <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">Cuti Anggota</header>
            <div class="panel-body">
                  <div class="adv-table">
<table  class="display table table-bordered table-striped" id="example">
<thead>
		<tr>
		<th>No</th>
		<th>NIP</th>
		<th>Nama</th>
		<th style = "width: 88px;"></th>
		<th style = "width: 88px;"></th>
	</tr>
</thead>
<tbody>
	<?php $i = 1; foreach($tampil as $row):?>
	<tr>
		<td><?php echo $i++;?></td>
		<td><?php echo $row->nip_pengguna;?></td>
		<td><?php echo $row->nama_pengguna;?></td>
		<td><a href="<?php echo base_url();?>beranda/tambahcuti/<?php echo $row->id_pengguna;?>">Ambil Cuti</a></td>
		<td><a href="<?php echo base_url();?>beranda/cutidiambil/<?php echo $row->id_pengguna;?>">Cuti diambil</a></td>
	</tr>
	<?php endforeach;?>
</tbody>	
</table>
</div>
</div>
</section>
</div>