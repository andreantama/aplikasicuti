 <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">Anggota</header>
            <div class="btn-group" style="margin:10px;">
                <a href="<?php echo base_url();?>beranda/tambahpengguna/" id="editable-sample_new" class="btn btn-info">
                    <i class="icon-plus"></i> Tambah Anggota
                 </a>   
            </div>
             <div class="panel-body">
                  <div class="adv-table">
                  	<table class="display table table-bordered table-striped" id="example">
						<thead>
						<tr>
							<th>No</th>
							<th>NIP</th>
							<th>Nama</th>
							<th>Alamat</th>
							<th>Telp</th>
							<th>Username</th>
							<th>Status</th>
							<th></th>
							<th></th>
						</tr>
						</thead>
						<tbody>
						<?php $i = 1; foreach($tampil as $row):?>
						<tr>
							<td><?php echo $i++;?></td>
							<td><?php echo $row->nip_pengguna;?></td>
							<td><?php echo $row->nama_pengguna;?></td>
							<td><?php echo $row->alamat_pengguna;?></td>
							<td><?php echo $row->telp_pengguna;?></td>
							<td><?php echo $row->username_pengguna;?></td>
							<td><?php echo $row->status_pengguna;?></td>
							<td><a href="<?php echo base_url();?>beranda/editpengguna/<?php echo $row->id_pengguna;?>">Edit</a></td>
							<td><a href="<?php echo base_url();?>beranda/hapuspengguna/<?php echo $row->id_pengguna;?>">Hapus</a></td>
						</tr>
						<?php endforeach;?>
						</tbody>
					</table>
                  </div>
             </div>
        </section>
</div>

