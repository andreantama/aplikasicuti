
 <div class="row">
    <div class="col-lg-12">
       <section class="panel">
          <header class="panel-heading">
              Tambah Anggota
          </header>
        <div class="panel-body">
			<?php echo form_open("", array("class" => "form-horizontal tasi-form"));?>
			<div class="form-group">
                <div class="col-lg-offset-2 col-lg-10">
     			<?php echo form_submit("simpan", "Simpan", "class='btn btn-info'");?>
     		    <a href="<?php echo base_url();?>beranda/pengguna/" class='btn btn-default' >Kembali</a>
                </div>
             </div>
				<div class="form-group">
				
				<label class="col-sm-2 col-sm-2 control-label">NIP</label>
					<div class="col-sm-10">
					<?php echo form_error("nip");?>
						<?php echo form_input(array("type" => "text", "name" => "nip", "value" => "$tampil->nip_pengguna", "class" => "form-control"));?>
				</div>
				</div>

			<div class="form-group">
			
			<label class="col-sm-2 col-sm-2 control-label">Nama</label>
			<div class="col-sm-10">
			<?php echo form_error("nama");?>
			<?php echo form_input(array("type" => "text", "name" => "nama", "value" => "$tampil->nama_pengguna", "class" => "form-control"));?>
			</div>
			</div>

			<div class="form-group">
			
			<label class="col-sm-2 col-sm-2 control-label">Alamat</label>
			<div class="col-sm-10">
			<?php echo form_error("alamat");?>
			<?php echo form_textarea(array("name" => "alamat", "value" => "$tampil->alamat_pengguna", "class" => "form-control"));?>
						</div>
				</div>

			<div class="form-group">
			
			<label class="col-sm-2 col-sm-2 control-label">Telp</label>
			<div class="col-sm-10">
			<?php echo form_error("telp");?>
			<?php echo form_input(array("type" => "text", "name" => "telp", "value" => "$tampil->telp_pengguna", "class" => "form-control"));?>
						</div>
				</div>

			<div class="form-group">
			
			<label class="col-sm-2 col-sm-2 control-label">Status</label>
			<div class="col-sm-10">
			<?php echo form_error("status");?>
			<?php echo form_dropdown('status', array("superadmin" => "Super Admin", "admin" => "Admin", "user" => "User"), $tampil->status_pengguna, array("class" => "form-control", "required"=>"TRUE"));?>
			<br>						</div>
				</div>
				<div class="form-group">
                <div class="col-lg-offset-2 col-lg-10">
     			<?php echo form_submit("simpan", "Simpan", "class='btn btn-info'");?>
     		    <a href="<?php echo base_url();?>beranda/pengguna/" class='btn btn-default' >Kembali</a>
                </div>
             </div>
			<?php echo form_close();?>
        </div>
        </section>
    </div>
 </div>