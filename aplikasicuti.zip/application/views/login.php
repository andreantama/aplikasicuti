<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="AndreanTama">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Aplikasi Cuti</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/style-responsive.css" rel="stylesheet" />
    <link href="<?php echo base_url();?>css/styleku.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

  <body class="login-body">
  <div class="container">
  <?php if($this->session->flashdata('notifikasierror') == TRUE):?>
	 <div class="alert alert-block alert-danger fade in">
            <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
            </button>
            <strong>Terjadi Kesalahan!</strong> Username dan Password tidak tepat
     </div>
  <?php endif;?>

		<?php echo form_open("", array("class" => "form-signin"));?>
		<h2 class="form-signin-heading">Sign In Now</h2>
		<div class="login-wrap">
		<?php echo form_error("username");?>
		<label>Username</label>
		<?php echo form_input(array("type" => "text", "name" => "username", "value" => set_value('username'), "class" => "form-control"));?>

		<?php echo form_error("password");?>
		<label>Password</label>
		<?php echo form_input(array("type" => "password", "name" => "password", "value" => "", "class" => "form-control"));?>

		<?php echo form_error("status");?>
		<label>Status</label>
		<?php echo form_dropdown('status', array("superadmin" => "Super Admin", "admin" => "Admin", "user" => "User"), 'Super Admin', array("class" => "form-control", "required"=>"TRUE"));?>
		</div>
		 <div class="modal-content">
		 <div class="modal-body" style="text-align:center;">
		<?php echo form_submit("simpan", "Masuk", "class='btn btn-success'");?>
		</div>
		</div>
		<?php echo form_close();?>

	</div>




	  <!-- js placed at the end of the document so the pages load faster -->
  <script src="<?php echo base_url();?>js/jquery.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo base_url();?>js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo base_url();?>js/jquery.scrollTo.min.js"></script>
    <script src="<?php echo base_url();?>js/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/gritter/js/jquery.gritter.js"></script>
    <script src="<?php echo base_url();?>js/respond.min.js" ></script>

    <!--common script for all pages-->
    <script src="<?php echo base_url();?>js/common-scripts.js"></script>

    <!--script for this page only-->
    <script src="<?php echo base_url();?>js/gritter.js" type="text/javascript"></script>
  </body>
</html>