<div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">Tanggal Cuti yang diambil</header>
            <div class="panel-body">
                  <div class="adv-table">
<table  class="display table table-bordered table-striped" id="example">
<thead>
<tr>
	<th>No</th>
	<th>Tahun</th>
	<th>Tanggal</th>
</tr>
</thead><tbody>
<?php $i = 1; foreach ($tampiljadwal as $row) :?>
<tr>
	<td><?php echo $i++;?></td>
	<td><?php echo $this->model->tampiltahun($row->id_jadwal)->tahun_jadwal;?></td>
	<td><?php echo $row->tanggal_jadwalpengguna;?></td>
	</tr>
<?php endforeach;?>
</tbody>
</table>