 <div class="row">
    <div class="col-lg-12">
       <section class="panel">
          <header class="panel-heading">
              Tambah Jadwal Cuti
          </header>
        <div class="panel-body">
<?php echo form_open("", array("class" => "form-horizontal tasi-form"));?>
	<div class="form-group">
                <div class="col-lg-offset-2 col-lg-10">
     			<?php echo form_submit("simpan", "Simpan", "class='btn btn-info'");?>
     		    <a href="<?php echo base_url();?>beranda/jadwalcuti/" class='btn btn-default' >Kembali</a>
                </div>
             </div>

     				<div class="form-group">
						<label class="col-sm-2 col-sm-2 control-label">Tahun</label>
											<div class="col-sm-10">

								<?php echo form_error("tahun");?>
								<?php echo form_input(array("type" => "text", "name" => "tahun", "value" => "", "class" => "form-control"));?>
							</div>
							</div>



					<div class="form-group">
						<label class="col-sm-2 col-sm-2 control-label">Cuti Bersama</label>
						<div class="col-sm-10">
							<?php echo form_error("cutibersama");?>
							<?php echo form_input(array("type" => "text", "name" => "cutibersama", "value" => "", "class" => "form-control"));?>
						</div>
						</div>



<?php echo form_close();?>
</section>
</div>
