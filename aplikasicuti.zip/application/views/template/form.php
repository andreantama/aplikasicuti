 <div class="row">
    <div class="col-lg-12">
       <section class="panel">
          <header class="panel-heading">
              Tambah Anggota
          </header>
        <div class="panel-body">
        	 <form class="form-horizontal tasi-form" method="get">
                                  <div class="form-group">
                                      <label class="col-sm-2 col-sm-2 control-label">Default</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="form-control">
                                      </div>
                                  </div>
        </div>
        </section>
    </div>
 </div>