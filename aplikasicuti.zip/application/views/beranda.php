<!--<html>
	<head>
		<title>Beranda</title>
	</head>
	<body>
	<?php 
	if($cekstatus == "superadmin"):?>
			<a href="<?php echo base_url();?>beranda/pengguna">Anggota</a>	
			<a href="<?php echo base_url();?>login/logout">Logout</a>
	<?php elseif($cekstatus == "admin"):?>
			<a href="<?php echo base_url();?>beranda/jadwalcuti">Jadwal Cuti</a>
			<a href="<?php echo base_url();?>beranda/cutianggota">Cuti Anggota</a>
			<a href="<?php echo base_url();?>login/logout">Logout</a>
	<?php elseif($cekstatus == "user"):?>
			<a href="<?php echo base_url();?>login/logout">Logout</a>
	<?php endif;?>	
	</body>
</html>-->