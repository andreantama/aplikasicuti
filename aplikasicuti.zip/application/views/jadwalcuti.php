 <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">Jadwal Cuti</header>
              <div class="btn-group" style="margin:10px;">
                <a href="<?php echo base_url();?>beranda/tambahjadwalcuti/" id="editable-sample_new" class="btn btn-info">
                    <i class="icon-plus"></i> Tambah Jadwal Cuti
                 </a>   
            </div>
            <div class="panel-body">
                  <div class="adv-table">
<table  class="display table table-bordered table-striped" id="example">
<thead>
	<tr>
		<th>No</th>
		<th>Tahun</th>
		<th>Cuti Bersama</th>
		<th></th>
		<th></th>
	</tr>
	</thead>
	<tbody>
		<?php $i = 1; foreach ($tampil as $row) :?>
		<tr>
			<td><?php echo $i++;?></td>
			<td><?php echo $row->tahun_jadwal;?></td>
			<td><?php echo $row->cutibersama_jadwal;?></td>
			<td><a href="<?php echo base_url();?>beranda/editjadwalcuti/<?php echo $row->id_jadwal;?>">Edit</a></td>
			<td><a href="<?php echo base_url();?>beranda/hapusjadwalcuti/<?php echo $row->id_jadwal;?>">Hapus</a></td>
		</tr>
	<?php endforeach;?>
	</tbody>
	
</table>
</div>
</div>
</section>
</div>