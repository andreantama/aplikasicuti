 <div class="row">
    <div class="col-lg-12">
       <section class="panel">
          <header class="panel-heading">
              Ambil Cuti
          </header>
             <div class="panel-body">
				<?php echo form_open("", array("class" => "form-horizontal tasi-form"));?>
				<div class="form-group">
                <div class="col-lg-offset-2 col-lg-10">
     			<?php echo form_submit("simpan", "Simpan", "class='btn btn-info'");?>
     		    <a href="<?php echo base_url();?>beranda/cutianggota/" class='btn btn-default' >Kembali</a>
                </div>
             </div>

				
				<div class="form-group">
				<label class="col-sm-2 col-sm-2 control-label">Tahun</label>
				<div class="col-sm-10">
				<select name="tahun" class="form-control">
				<?php echo form_error("tahun");?>
					<?php foreach ($tampiltahun as $row) :?>
						<?php $sisa = $this->model->sisacuti($idanggota, $row->id_jadwal, $row->sisacuti_jadwal);
						if($sisa != 0):
							?>
						<option value="<?php echo $row->id_jadwal;?>"><?php echo $row->tahun_jadwal."<i>   Sisa cuti = </i>".
						$sisa
						;?></option>
					<?php endif; endforeach;?>
				</select>
				</div>
				</div>

			
				
				    <div class="form-group">
                                  <label class="control-label col-md-3">Tanggal</label>
                                  <div class="col-md-3 col-xs-11">

                                      <div data-date-viewmode="years" data-date-format="dd-mm-yyyy" data-date="12-02-2016"  class="input-append date dpYears">
                                          <?php echo form_error("tanggal");?>
                                          <input type="text" readonly="" value="12-02-2012" size="16" class="form-control" name="tanggal">
                                              <span class="input-group-btn add-on">
                                                <button class="btn btn-danger" type="button"><i class="icon-calendar"></i></button>
                                              </span>
                                      </div>
                                      <span class="help-block">Select date</span>
                                  </div>
                              </div>
				<?php echo form_close();?>
				</div>
				</section>
				</div>
				